-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 17, 2022 at 05:35 PM
-- Server version: 10.3.34-MariaDB-0+deb10u1
-- PHP Version: 7.3.31-1~deb10u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e2195171`
--

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_birthday` date NOT NULL,
  `city_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `address`, `phone`, `email`, `date_birthday`, `city_id`) VALUES
(1, 'Ole Gerhold', '238 Kautzer PlainFinnshire, MO 36064', '(743) 612-9303', 'nicolas.gloria@stanton.com', '2005-12-13', 12),
(2, 'Selmer Weissnat', '3685 Gottlieb Walk\nSouth Janick, AR 17397-3650', '+1 (251) 261-5429', 'simonis.hildegard@gmail.com', '2000-02-04', 9),
(3, 'Ernestine Koelpin', '39435 Wolf Parkway Suite 206\nJacobichester, TN 18373', '+1-660-342-8315', 'camila.goyette@yahoo.com', '2010-05-31', 5),
(4, 'Miss Freeda Waters V', '73270 Murazik Greens Suite 325\nConnellyfurt, IN 27393-6683', '+12202337782', 'hilda15@gmail.com', '2000-05-13', 3),
(5, 'Kariane Schuppe', '8019 Crystal Avenue Apt. 995\nRunteborough, KS 55265-7420', '(915) 341-3895', 'makenna57@douglas.net', '2008-12-08', 7),
(6, 'Gerson Fahey', '713 Michelle Trace\nSouth Nayeliburgh, NM 39605', '820.830.2947', 'alysa.block@blanda.net', '1986-04-05', 2),
(7, 'Mr. Tod Robel', '92644 Jaquelin Lakes\nCrooksport, NH 75987-2660', '1-484-652-5656', 'ledner.candida@rolfson.com', '2011-04-29', 1),
(8, 'Norma Hauck', '87705 Steuber Points Apt. 248\nKoreyshire, SC 67711', '341-644-9166', 'nathan08@yahoo.com', '1998-01-16', 8),
(9, 'Lera Thiel', '19531 Friesen Prairie Apt. 428\nZionview, WI 18063', '(678) 473-2746', 'oconnell.emelie@hotmail.com', '1994-10-04', 10),
(10, 'Prof. Rebeca Donnelly', '343 Balistreri Forge\nWest Zariaport, WI 36031', '1-530-752-7490', 'marks.andre@walker.com', '2009-08-12', 9),
(11, 'Mrs. Ericka Goldner IV', '135 Wilfred Junctions\nPort Brennaside, GA 42678', '1-424-404-0201', 'nels.bernier@yahoo.com', '1986-04-02', 1),
(12, 'Andrew Daugherty', '13094 Isidro Extension\nSouth Fredericborough, MD 16626-5726', '1-361-649-5059', 'grayson36@mills.com', '2019-02-09', 3),
(13, 'Austyn Stamm', '6826 Okuneva Parkway\nMackfurt, ID 97643', '973-394-6100', 'zaria.rowe@frami.info', '2009-03-01', 13),
(14, 'Emory Stanton', '6441 Rae Mountains\nAdalbertomouth, KS 22919', '401.304.8770', 'zmorissette@yahoo.com', '2012-10-17', 1),
(15, 'Hosea Jerde', '820 Grimes Meadows Suite 339\nEast Annaliseborough, MI 32442-6285', '+15122189681', 'viviane.ankunding@okuneva.com', '1995-08-29', 14),
(16, 'Tyrique Buckridge', '8257 Lavonne Roads\nWest Ashly, OH 40027', '(413) 683-9499', 'reggie67@hotmail.com', '2002-11-20', 8),
(17, 'Mrs. Addie Hansen', '24843 Carolanne Stravenue\nWest Allanland, NE 09129', '(510) 765-2980', 'melvin98@gmail.com', '2012-11-18', 12),
(18, 'Amelia Fritsch', '900 Romaguera Drive Suite 985\nCalebburgh, SC 22689', '+1-843-289-4567', 'cary.abernathy@davis.com', '1970-06-10', 9),
(19, 'Mr. Gunnar Bins', '63796 Lexi Cliffs Suite 404\nNew Daytonberg, LA 19512-7595', '530-545-4504', 'trystan71@muller.com', '1990-04-06', 7),
(20, 'Maxie Goldner', '62112 Lesch Walks\nLake Carolynland, OH 74761-4207', '+1-240-342-1987', 'victoria.howe@yundt.com', '1995-10-01', 13),
(21, 'Edgar Hahn', '958 Damian Ranch Apt. 845\nNorth Ruthieville, MD 68947', '603-456-1900', 'jconroy@yahoo.com', '1973-10-31', 10),
(22, 'Claudie Erdman', '1635 Kilback Roads Suite 515\nSchultztown, NM 23270-7432', '+12794537962', 'ioconnell@ryan.com', '1990-08-25', 8),
(23, 'Dr. Kristin Tremblay', '6452 Medhurst Ferry\nTillmanberg, TX 23238-8296', '+13256200335', 'delbert.adams@tremblay.com', '2012-02-27', 14),
(24, 'Prof. Muriel Witting', '99149 Reilly View Apt. 966\nHoppemouth, KY 86871-5301', '541.370.2817', 'carroll99@yahoo.com', '1997-07-07', 3),
(25, 'Terence Reilly', '8075 Hill Heights Suite 755\nAlbertaview, WY 37379-7287', '941.232.2554', 'krau@gmail.com', '2004-03-03', 13),
(26, 'Dr. Nickolas Blanda', '9695 Turcotte Turnpike Apt. 227\nPort Darwinside, MN 46006-5689', '1-435-891-5097', 'jmayert@kassulke.com', '1988-04-18', 12),
(27, 'Orville Davis', '76345 Gulgowski Street\nWest Carmine, MS 95564-9258', '+1-317-730-1916', 'uturner@hotmail.com', '2012-04-01', 10),
(28, 'Prof. Arne Kozey PhD', '5080 Ankunding Coves\nSouth Suzannehaven, TX 57238-0508', '+1.469.317.5166', 'juliet.mccullough@mcclure.com', '2015-02-03', 9),
(29, 'Mr. Narciso Nicolas', '1714 Fay Lakes Apt. 701\nEast Marcellusmouth, TN 41331-0477', '1-806-439-5657', 'abdul.steuber@hotmail.com', '2006-07-04', 7),
(30, 'Amaya Kutch', '60110 Eichmann Stream Suite 281\nSouth Hettiefort, NC 07293-5720', '+1 (629) 389-8353', 'oquitzon@gmail.com', '1991-04-08', 15),
(31, 'Prof. Maximus Jones DVM', '10974 Eunice Extension Suite 301\nToyside, ME 75275-2899', '+13604762489', 'clyde90@marks.com', '2021-11-03', 14),
(32, 'Olen Haley Jr.', '74276 Godfrey Extension\nNew Peter, MO 83949', '1-925-870-2189', 'okon.salma@abshire.biz', '2012-03-13', 4),
(33, 'Mrs. Burdette Armstrong III', '858 Adrienne Ports Apt. 657\nEast Rory, AL 31395-8670', '386-708-9735', 'kutch.abelardo@gmail.com', '2019-01-15', 8),
(34, 'Jarod Hudson', '72332 Welch Crest Suite 580\nDamarishaven, RI 93438', '1-906-202-1660', 'mosciski.libby@hilpert.biz', '2009-04-27', 13),
(35, 'Keyon Doyle', '435 Borer Mews\nRueckerfort, FL 86156-1812', '1-562-804-5206', 'tbergstrom@hotmail.com', '1973-06-25', 12),
(36, 'Tess Fahey', '809 Krajcik Station Apt. 934\nAileenmouth, NY 38385-4532', '(914) 376-8209', 'lokon@dickinson.info', '2007-12-01', 9),
(37, 'Jordyn Mosciski', '859 Farrell Square Apt. 127\nPort Wilhelminemouth, NJ 47708-2507', '+13517948785', 'daron.farrell@terry.net', '2008-04-29', 10),
(38, 'Oran Fadel', '34370 McKenzie Trail Apt. 925\nSheashire, MO 66760-7522', '+1-860-575-3329', 'muller.emma@yahoo.com', '2001-06-23', 5),
(39, 'Mr. Zackery Hill V', '710 Pagac Point Apt. 194\nKozeyfort, CA 48573', '+1.386.446.4152', 'kassulke.demond@mclaughlin.com', '1980-08-25', 7),
(40, 'Haley O\'Connell', '6454 Taylor Burg\nNew Carson, VT 43225-9647', '(734) 574-1858', 'cassin.marjorie@gmail.com', '1986-04-29', 6),
(41, 'Prof. Zetta Skiles Jr.', '6637 Josephine Tunnel\nWest Kaelyn, NE 57356-0528', '351.215.9979', 'ucollins@gmail.com', '1970-06-04', 3),
(42, 'Alberta Ernser', '93360 Swift Mall\nLibbiefort, MD 63698', '+12834085084', 'elouise96@flatley.net', '2003-09-27', 10),
(43, 'Carlos Zulauf', '4485 Terry Ports Apt. 485\nTiannaport, IA 15455-9512', '351.801.5827', 'stark.leopoldo@jenkins.info', '1979-04-01', 8),
(44, 'Elinor Murazik', '860 Gregg Route\nNew Mara, KS 06944', '+18727248075', 'marvin.bernhard@yahoo.com', '2001-08-17', 6),
(45, 'Dr. Shanelle Roberts I', '502 Harrison Forges\nNorth Lavernemouth, ND 22670-2440', '(937) 710-1464', 'cpagac@kozey.info', '1977-05-06', 13),
(46, 'Prof. Drake Goyette', '991 Schultz Falls\nRogelioborough, AK 79996', '+1-803-759-9207', 'jada.schiller@kautzer.com', '2000-07-08', 13),
(47, 'Greyson Crist', '5921 Ima Shore Apt. 790\nNew Dock, AZ 86184-9068', '+1 (602) 239-9267', 'domenica35@gmail.com', '2014-03-15', 9),
(48, 'Hobart Orn', '51201 Wintheiser Pike Apt. 402\nPort Aaliyah, LA 02725', '+16574588947', 'libby44@gmail.com', '2013-04-07', 14),
(49, 'Glenna Deckow II', '8548 Klein Trail\nSchulistchester, OK 04017-1930', '(341) 894-5763', 'xsatterfield@kuhic.net', '1970-03-02', 14),
(50, 'Mabelle Pacocha', '30264 Borer Squares\nSouth Lonny, NE 94428', '+1-507-209-5078', 'lakin.pascale@rutherford.net', '1996-04-26', 2),
(51, 'Laurianne Haag', '73341 Macy Flats\nRusselbury, ID 62723-3937', '1-512-735-2089', 'margot15@hotmail.com', '1997-11-12', 11),
(52, 'Kaleb O\'Keefe', '5304 Hudson Islands Suite 526\nParkermouth, VA 01912', '(952) 603-3962', 'ylittel@crist.com', '2020-09-27', 13),
(53, 'Phyllis Wyman', '9778 Hermann Village\nNorth Soniatown, MN 88843-3981', '+1-240-287-8335', 'corwin.irma@fisher.com', '1982-07-14', 5),
(54, 'Mrs. Kaylie Ritchie', '55779 Rogelio Views Apt. 091\nPort Elroyborough, MN 82851-7006', '571.963.3025', 'emerald22@mayer.info', '2012-10-18', 4),
(55, 'Camron Casper', '9871 Beatty Skyway\nLake Maeveberg, CT 30563-8479', '+1-669-780-9044', 'ernest87@shields.com', '1998-10-27', 12),
(56, 'Grover Mann I', '486 Michele Plaza\nXandertown, IA 21051-6033', '+1-210-764-0802', 'jaclyn.brown@yahoo.com', '2002-02-19', 8),
(57, 'Magnolia White Jr.', '24330 Parker Cape\nBartolettiview, HI 66086-5841', '(865) 853-7973', 'ojones@hotmail.com', '1981-10-08', 8),
(58, 'Prof. Leola Collier', '493 Whitney Prairie\nOrintown, GA 93240', '1-938-608-8477', 'niko.swaniawski@gmail.com', '1996-12-13', 14),
(59, 'Dina Flatley DVM', '8826 Wuckert Manor\nNew Colt, VA 57191', '+1-562-309-2581', 'krystal76@stanton.net', '1997-12-15', 13),
(60, 'Narciso Feest', '5165 Willis Bridge Suite 539\nOberbrunnerburgh, CO 69694-6085', '938.203.7577', 'pbreitenberg@gmail.com', '1972-01-05', 11),
(61, 'Chyna Prohaska II', '63293 Larson Burg Suite 424\nPort Garfield, ID 00462-9355', '+1-810-975-3627', 'konopelski.ada@hickle.org', '2008-01-24', 12),
(62, 'Tamia Hodkiewicz', '4548 Bailey Rue\nEast Adonisside, MO 46529', '303.914.2435', 'hegmann.kenny@pacocha.org', '1984-02-16', 2),
(63, 'Rod Ruecker', '6025 Baumbach Expressway\nHuelport, DC 36112', '423.540.5968', 'thaddeus92@rodriguez.com', '2012-07-06', 13),
(64, 'Vicente Abshire', '843 Naomie Brooks\nFaystad, DE 04811-9276', '408-880-7863', 'hill.rafael@hessel.org', '2000-10-20', 6),
(65, 'Prof. Bennett Schultz', '84975 Kilback Ports Suite 944\nLefflerborough, WV 40172', '+16462515829', 'anais.hermann@streich.com', '1988-02-19', 3),
(66, 'Catalina Hayes', '274 Anderson Junctions Apt. 837\nKayleefurt, OR 34936', '1-747-665-5596', 'gerlach.angie@mills.biz', '2010-12-14', 8),
(67, 'Rhea Bins', '588 Norbert Squares\nWalshtown, IA 17119-2118', '+1-786-781-5165', 'ashleigh87@mitchell.com', '1989-10-14', 6),
(68, 'Dr. Emmalee Predovic', '98271 Keara Loaf\nLake Nealfurt, MA 84485', '1-949-643-4109', 'ceasar.bosco@hotmail.com', '1986-04-29', 9),
(69, 'Sheridan Schowalter', '12010 Harmon Fields\nOthaside, NE 51724', '360.360.3833', 'lebsack.thomas@yahoo.com', '2000-03-13', 14),
(70, 'Prof. Danielle Waters DVM', '44385 Kohler Mountains\nWest Erna, ND 29633', '541.764.7890', 'hbarrows@hotmail.com', '1987-09-24', 12),
(71, 'Fleta Jerde', '662 Keeling Rapid\nBoehmbury, NY 95553-6666', '+1 (479) 991-6963', 'maye85@hotmail.com', '2010-01-18', 15),
(72, 'Mrs. Karlee Rau', '2457 Skiles Freeway\nAngelinaberg, SD 97058-2708', '1-878-949-4035', 'cyril.hauck@stiedemann.biz', '1987-10-28', 6),
(73, 'Mr. Jordy Heathcote', '26107 Madalyn Union Apt. 057\nNorth Keven, NC 79549-8557', '984-257-6380', 'rlueilwitz@gmail.com', '2020-05-04', 13),
(74, 'Cristobal McKenzie', '5994 Velma Run\nLake Katrinahaven, WA 11418', '(865) 247-0144', 'maryam.kreiger@hotmail.com', '1973-09-04', 8),
(75, 'Lawson Kris', '6697 Hahn Knoll Apt. 047\nGreenfelderborough, UT 23236', '+12239929360', 'ndoyle@hansen.info', '2009-06-23', 8),
(76, 'Nola Hansen', '32237 Mathias Points\nEast Elinore, UT 18483', '(878) 233-5213', 'rhoda.walsh@mclaughlin.biz', '2005-08-13', 11),
(77, 'Prof. Cathrine Emmerich III', '238 Wolf Drive Suite 450\nNorth Everetteside, AL 02455', '+1.781.564.2124', 'ankunding.juliet@gmail.com', '1987-01-10', 2),
(78, 'Russ Macejkovic', '75592 Antoinette Plains Suite 595\nSantiagohaven, KY 35765', '(504) 745-1244', 'maudie.dubuque@wolf.com', '2021-01-02', 1),
(79, 'Kieran Raynor', '734 Courtney Isle\nWest Jonathanside, GA 37258', '(620) 261-7059', 'runte.idell@yahoo.com', '1996-04-28', 6),
(80, 'Miss Marina Rohan', '7428 Krajcik Manors Apt. 911\nLake Carson, MS 24394', '252-753-6676', 'martin19@gmail.com', '1989-06-03', 7),
(81, 'Cheyenne Bins', '2664 Columbus Fort\nDurganberg, DE 36277-3926', '743-927-2835', 'kristina.green@king.info', '2019-03-10', 15),
(82, 'Dr. Norbert Fahey', '272 Schroeder Glen\nPort Jaleel, NM 86228-7851', '(947) 286-0839', 'hope08@yahoo.com', '1989-04-14', 10),
(83, 'Demetris Jast', '530 Creola Springs\nDavischester, SD 86384', '1-743-257-2837', 'blair61@yahoo.com', '2015-06-20', 14),
(84, 'Flavie Lockman', '7855 Yost Parkway Suite 831\nPollichberg, MN 75401-5473', '+1-240-730-6991', 'santa.schuppe@gmail.com', '1988-07-20', 13),
(85, 'Kaela Deckow', '89903 Von Lodge\nAbbigailton, MS 97853-9334', '+1.262.738.5424', 'margaret85@zboncak.com', '2003-02-01', 13),
(86, 'Hailee Effertz', '87258 Everardo Viaduct\nWest Nolan, AK 70741', '+1.984.389.0149', 'rgreenholt@smitham.com', '2000-08-26', 5),
(87, 'Carmel Mann', '6618 Verdie Knoll\nPort Kaylie, CO 07369', '(956) 784-3418', 'hhammes@wisozk.org', '2011-01-13', 4),
(88, 'Adolphus Murphy', '4273 Nicolas Curve\nWest Adaline, MD 21575', '605-397-1993', 'jmurphy@hotmail.com', '2014-11-14', 4),
(89, 'Dr. Rafael Effertz', '87539 Monahan Center Suite 496\nNew Israel, IN 39687-2329', '213.906.7294', 'gusikowski.kiera@yahoo.com', '2002-01-01', 11),
(90, 'Heather Johnston', '487 Boyer Motorway Apt. 643\nLake Milfordhaven, HI 08416', '820-246-8730', 'nmorissette@fadel.biz', '1982-05-22', 4),
(91, 'Estrella Ortiz', '701 Bryce Haven\nEast Sid, KS 62439-7309', '+1.725.717.6926', 'deckow.raul@yahoo.com', '2012-08-09', 3),
(92, 'Sophie Ledner', '2880 Madilyn Mall\nWest Karlie, RI 19331', '480-946-7754', 'wstreich@muller.info', '2002-01-06', 8),
(93, 'Madilyn Ruecker', '296 Eliezer Neck Suite 730\nNew Alyceburgh, PA 38110', '(209) 681-0109', 'wilton.bartell@bahringer.info', '1971-11-26', 11),
(94, 'Lucie Murazik', '6291 Stevie Passage\nSchaeferstad, ID 82359', '+13398555180', 'zoe.hartmann@pfeffer.biz', '1998-07-05', 5),
(95, 'Rosalee Willms IV', '92753 Franecki Turnpike Apt. 100\nDarwinberg, VA 79223', '360-886-4951', 'abigale.johns@yahoo.com', '1999-01-08', 3),
(96, 'Prof. Emil Schneider', '1832 Heathcote Isle Apt. 701\nLake Audie, OR 27891-5195', '+1 (540) 980-8126', 'aliza.kshlerin@yahoo.com', '2009-08-14', 10),
(97, 'Ernestine Ledner', '326 Streich Haven Suite 659\nLavonneborough, MI 95859', '929-636-5211', 'rosendo.lockman@hotmail.com', '2011-04-30', 5),
(98, 'Ada Witting', '311 Karen Inlet\nNew Kraigtown, WV 70422', '+1-815-345-0923', 'tcrona@hotmail.com', '2005-05-14', 12),
(99, 'Prof. Roselyn Walsh', '33994 Hadley Vista Suite 822\nLake Kaitlyn, VT 43847-0335', '325-851-5715', 'stephan54@gmail.com', '1985-09-12', 14),
(100, 'Tyrese Lesch', '58763 Damian Springs\nSouth Isac, NE 63503', '1-706-318-8614', 'marge.spinka@weber.org', '1992-12-04', 13);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=109;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
